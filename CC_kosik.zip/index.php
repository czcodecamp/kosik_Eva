<?php

require('db_eshop.php');

?>

<h1>VÍTEJTE V ESHOPU! :)</h1>

<a href='produkty.php'>
		<button>Vstupte!</button> 
</a>

